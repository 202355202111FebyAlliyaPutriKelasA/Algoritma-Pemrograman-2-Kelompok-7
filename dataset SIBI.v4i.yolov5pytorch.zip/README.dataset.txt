# dataset SIBI > 2024-07-16 2:37pm
https://universe.roboflow.com/aplikasi-deteksi-bahasa-isyarat/dataset-sibi

Provided by a Roboflow user
License: CC BY 4.0

